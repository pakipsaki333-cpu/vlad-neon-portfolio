import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Владислав — мастер световых вывесок и неона | Портфолио",
  description:
    "Владислав — мастер по изготовлению, ремонту и восстановлению световых и неоновых вывесок. Более 10 лет опыта. Неон, объёмные буквы, световые короба, электрика, монтаж.",
  keywords: [
    "мастер вывесок",
    "неоновые вывески",
    "ремонт вывесок",
    "восстановление вывесок",
    "объёмные буквы",
    "световые короба",
    "монтаж вывесок",
    "Владислав неон",
  ],
  openGraph: {
    title: "Владислав — мастер световых вывесок и неона",
    description:
      "Создаю и восстанавливаю световые вывески любой сложности. Неон • Ремонт • Восстановление • Монтаж",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#050608",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru" className={inter.variable}>
      <body>{children}</body>
    </html>
  );
}
