import Image from "next/image";
import { CONTACTS } from "./data";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-28 pb-20"
    >
      {/* Background image */}
      <div className="absolute inset-0 -z-10">
        <Image
          src="/images/sign_08.jpg"
          alt="Световая вывеска"
          fill
          priority
          sizes="100vw"
          className="object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#050608]/80 via-[#050608]/90 to-[#050608]" />
        <div className="absolute inset-0 grid-bg animate-[gridScroll_18s_linear_infinite]" />
      </div>

      {/* Glow blobs */}
      <div className="pointer-events-none absolute -top-24 right-0 h-96 w-96 rounded-full bg-[var(--neon)]/15 blur-[130px] animate-[floatSlow_9s_ease-in-out_infinite]" />
      <div className="pointer-events-none absolute bottom-0 left-0 h-80 w-80 rounded-full bg-[var(--neon)]/10 blur-[130px]" />

      <div className="mx-auto max-w-4xl px-4 sm:px-6 w-full text-center">
        <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-2 text-xs sm:text-sm text-[var(--neon-soft)] mb-8 reveal in">
          <span className="h-2 w-2 rounded-full bg-[var(--neon)] flicker" />
          {CONTACTS.name} • {CONTACTS.role}
        </span>

        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold leading-[1.08] tracking-tight reveal in">
          Создаю и восстанавливаю{" "}
          <span className="neon-text">световые вывески</span> любой сложности
        </h1>

        <p className="mt-7 text-base sm:text-xl text-[var(--muted)] max-w-2xl mx-auto reveal in">
          Неон • Световые вывески • Объёмные буквы • Ремонт • Монтаж
        </p>

        <p className="mt-4 text-sm sm:text-base text-[var(--muted)]/80 max-w-xl mx-auto reveal in">
          Более 10 лет опыта в создании, ремонте и восстановлении рекламных
          конструкций.
        </p>

        <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4 reveal in">
          <a
            href={CONTACTS.phoneHref}
            className="btn-neon rounded-full px-8 py-4 text-base inline-flex items-center justify-center gap-2"
          >
            <span>📞</span> Позвонить
          </a>
          <a
            href={CONTACTS.telegram}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost rounded-full px-8 py-4 text-base inline-flex items-center justify-center gap-2"
          >
            <span>✈️</span> Telegram
          </a>
          <a
            href="#gallery"
            className="btn-ghost rounded-full px-8 py-4 text-base inline-flex items-center justify-center gap-2"
          >
            <span>🖼️</span> Посмотреть работы
          </a>
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[var(--muted)] hidden sm:flex flex-col items-center gap-2 text-xs animate-[floatSlow_3s_ease-in-out_infinite]"
      >
        Листайте вниз
        <span className="text-lg">↓</span>
      </a>
    </section>
  );
}
