export const CONTACTS = {
  name: "Владислав",
  role: "Мастер световых вывесок и неона",
  phone: "89028874977",
  phoneHref: "tel:+79028874977",
  phonePretty: "8 (902) 887-49-77",
  telegram: "https://t.me/PakiPsaki",
  telegramHandle: "@PakiPsaki",
};

export const aboutText = [
  "Меня зовут Владислав.",
  "Более 10 лет занимаюсь изготовлением и ремонтом световых вывесок.",
  "Создаю новые проекты и восстанавливаю конструкции, которые требуют профессионального ремонта.",
];

export const services = [
  { title: "Неоновые вывески", icon: "neon" },
  { title: "Объёмные буквы", icon: "letters" },
  { title: "Световые короба", icon: "box" },
  { title: "Ремонт вывесок", icon: "repair" },
  { title: "Монтаж", icon: "mount" },
];

// ===== Галерея: все фото лежат локально в public/images =====
export const galleryCategories = [
  "Все",
  "Неон",
  "Вывески",
  "Ремонт",
  "Монтаж",
] as const;

export type GalleryCategory = (typeof galleryCategories)[number];

const CATEGORY_CYCLE: Exclude<GalleryCategory, "Все">[] = [
  "Неон",
  "Вывески",
  "Ремонт",
  "Монтаж",
];

export type GalleryItem = {
  src: string;
  category: Exclude<GalleryCategory, "Все">;
};

// 49 фотографий, распределённых по категориям
export const galleryImages: GalleryItem[] = Array.from({ length: 49 }, (_, i) => ({
  src: `/images/sign_${String(i + 1).padStart(2, "0")}.jpg`,
  category: CATEGORY_CYCLE[i % CATEGORY_CYCLE.length],
}));

export const reviews = [
  {
    name: "Алексей",
    text: "Влад восстановил вывеску, которую уже хотели заменить. Получилось как новая.",
  },
  {
    name: "Марина",
    text: "Заказывали изготовление неона. Очень аккуратная работа.",
  },
  {
    name: "Дмитрий",
    text: "Быстро нашёл проблему и исправил неисправность.",
  },
  {
    name: "Ольга",
    text: "Мигающую вывеску починил за один день. Спасибо за работу!",
  },
];
