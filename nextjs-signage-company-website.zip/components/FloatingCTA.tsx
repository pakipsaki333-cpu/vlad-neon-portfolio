import { CONTACTS } from "./data";

export default function FloatingCTA() {
  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col gap-3">
      <a
        href={CONTACTS.telegram}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Написать в Telegram"
        className="flex h-14 w-14 items-center justify-center rounded-full glass text-2xl hover:scale-110 hover:text-[var(--neon)] transition-all shadow-lg"
      >
        ✈️
      </a>
      <a
        href={CONTACTS.phoneHref}
        aria-label="Позвонить"
        className="flex h-14 w-14 items-center justify-center rounded-full btn-neon text-2xl"
      >
        📞
      </a>
    </div>
  );
}
