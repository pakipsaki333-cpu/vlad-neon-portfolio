"use client";

/* eslint-disable @next/next/no-img-element */
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  galleryCategories,
  galleryImages,
  type GalleryCategory,
} from "./data";

export default function Gallery() {
  const [category, setCategory] = useState<GalleryCategory>("Все");
  const [active, setActive] = useState<number | null>(null);
  const [visibleCount, setVisibleCount] = useState(12);

  const filtered = useMemo(
    () =>
      category === "Все"
        ? galleryImages
        : galleryImages.filter((g) => g.category === category),
    [category],
  );

  const close = useCallback(() => setActive(null), []);
  const prev = useCallback(
    () =>
      setActive((i) =>
        i === null ? i : (i + filtered.length - 1) % filtered.length,
      ),
    [filtered.length],
  );
  const next = useCallback(
    () => setActive((i) => (i === null ? i : (i + 1) % filtered.length)),
    [filtered.length],
  );

  useEffect(() => {
    if (active === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [active, close, prev, next]);

  const changeCategory = (c: GalleryCategory) => {
    setCategory(c);
    setVisibleCount(12);
    setActive(null);
  };

  const shown = filtered.slice(0, visibleCount);

  return (
    <section id="gallery" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-sm uppercase tracking-[0.3em] text-[var(--neon-soft)]">
            Портфолио
          </span>
          <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold tracking-tight">
            Мои <span className="neon-text">работы</span>
          </h2>
        </div>

        {/* Category filter */}
        <div className="mb-12 flex flex-wrap justify-center gap-2 sm:gap-3">
          {galleryCategories.map((c) => (
            <button
              key={c}
              onClick={() => changeCategory(c)}
              className={`rounded-full px-5 py-2.5 text-sm font-medium transition-all duration-300 ${
                category === c
                  ? "btn-neon"
                  : "glass text-[var(--muted)] hover:text-white"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="masonry">
          {shown.map((item, i) => (
            <button
              key={item.src}
              onClick={() => setActive(i)}
              className="masonry-item group relative block w-full overflow-hidden rounded-2xl glass p-1.5 cursor-pointer"
              style={{
                animation: `fadeUp 0.7s cubic-bezier(0.22,1,0.36,1) ${(i % 12) * 60}ms both`,
              }}
              aria-label={`Открыть фото ${i + 1}`}
            >
              <img
                src={item.src}
                alt={`Работа мастера — ${item.category} ${i + 1}`}
                loading="lazy"
                className="w-full rounded-xl object-cover transition-transform duration-700 group-hover:scale-[1.06]"
              />
              <span className="pointer-events-none absolute inset-1.5 rounded-xl bg-gradient-to-t from-[#050608]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <span className="pointer-events-none absolute top-3 left-3 rounded-full glass px-3 py-1 text-xs text-[var(--neon-soft)] opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                {item.category}
              </span>
              <span className="pointer-events-none absolute bottom-4 left-4 flex items-center gap-2 text-sm font-medium text-white opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--neon)] text-[#041016]">
                  ⤢
                </span>
                Смотреть
              </span>
            </button>
          ))}
        </div>

        {visibleCount < filtered.length && (
          <div className="mt-12 text-center">
            <button
              onClick={() => setVisibleCount((c) => c + 12)}
              className="btn-ghost rounded-full px-8 py-4"
            >
              Показать ещё
            </button>
          </div>
        )}
      </div>

      {/* Lightbox */}
      {active !== null && filtered[active] && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-md p-4"
          onClick={close}
        >
          <button
            onClick={close}
            aria-label="Закрыть"
            className="absolute top-5 right-5 flex h-12 w-12 items-center justify-center rounded-full glass text-2xl hover:text-[var(--neon)] transition-colors"
          >
            ✕
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              prev();
            }}
            aria-label="Предыдущее"
            className="absolute left-3 sm:left-8 flex h-12 w-12 items-center justify-center rounded-full glass text-2xl hover:text-[var(--neon)] transition-colors"
          >
            ‹
          </button>
          <img
            src={filtered[active].src}
            alt={`Работа мастера — ${filtered[active].category}`}
            onClick={(e) => e.stopPropagation()}
            className="lightbox-img max-h-[86vh] max-w-[92vw] rounded-2xl object-contain shadow-2xl"
          />
          <button
            onClick={(e) => {
              e.stopPropagation();
              next();
            }}
            aria-label="Следующее"
            className="absolute right-3 sm:right-8 flex h-12 w-12 items-center justify-center rounded-full glass text-2xl hover:text-[var(--neon)] transition-colors"
          >
            ›
          </button>
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 glass rounded-full px-4 py-2 text-sm text-[var(--muted)]">
            {filtered[active].category} · {active + 1} / {filtered.length}
          </div>
        </div>
      )}
    </section>
  );
}
