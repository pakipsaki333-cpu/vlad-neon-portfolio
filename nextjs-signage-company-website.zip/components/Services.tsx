import Reveal from "./Reveal";
import { services } from "./data";

function Icon({ name }: { name: string }) {
  const common = "w-7 h-7";
  switch (name) {
    case "neon":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={common} stroke="currentColor" strokeWidth="1.6">
          <path d="M4 16c0-5 3-9 8-9s8 4 8 9" strokeLinecap="round" />
          <path d="M7 19c0-3 2-6 5-6s5 3 5 6" strokeLinecap="round" />
        </svg>
      );
    case "letters":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={common} stroke="currentColor" strokeWidth="1.6">
          <path d="M4 18V6l4 8 4-8v12" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M16 6h4M18 6v12" strokeLinecap="round" />
        </svg>
      );
    case "box":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={common} stroke="currentColor" strokeWidth="1.6">
          <rect x="3" y="6" width="18" height="12" rx="2" />
          <path d="M7 10h10M7 14h6" strokeLinecap="round" />
        </svg>
      );
    case "mount":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={common} stroke="currentColor" strokeWidth="1.6">
          <path d="M14 4l6 6-3 3-6-6z" strokeLinejoin="round" />
          <path d="M11 7l-7 7v6h6l7-7" strokeLinejoin="round" />
        </svg>
      );
    case "repair":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={common} stroke="currentColor" strokeWidth="1.6">
          <path d="M14 6a3.5 3.5 0 00-4.5 4.5L4 16v4h4l5.5-5.5A3.5 3.5 0 0018 10l-2 2-2-2 2-2a3.5 3.5 0 00-2-2z" strokeLinejoin="round" />
        </svg>
      );
    case "electric":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={common} stroke="currentColor" strokeWidth="1.6">
          <path d="M13 3L5 13h5l-1 8 8-11h-5z" strokeLinejoin="round" strokeLinecap="round" />
        </svg>
      );
    default:
      return null;
  }
}

export default function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-sm uppercase tracking-[0.3em] text-[var(--neon-soft)]">
              Услуги
            </span>
            <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold tracking-tight">
              Чем я <span className="neon-text">занимаюсь</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid gap-5 grid-cols-2 lg:grid-cols-5">
          {services.map((s, i) => (
            <Reveal key={s.title} delay={i * 90}>
              <div className="glass glass-hover group rounded-3xl p-8 h-full flex flex-col items-center text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[var(--neon)]/10 text-[var(--neon)] ring-1 ring-[var(--neon)]/25 transition-transform duration-500 group-hover:scale-110">
                  <Icon name={s.icon} />
                </div>
                <h3 className="mt-6 text-base sm:text-lg font-semibold">
                  {s.title}
                </h3>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
