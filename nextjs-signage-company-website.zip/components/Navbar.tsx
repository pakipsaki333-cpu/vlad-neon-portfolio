"use client";

import { useEffect, useState } from "react";
import { CONTACTS } from "./data";

const links = [
  { href: "#about", label: "О мастере" },
  { href: "#services", label: "Услуги" },
  { href: "#gallery", label: "Портфолио" },
  { href: "#reviews", label: "Отзывы" },
  { href: "#contacts", label: "Контакты" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3" : "py-5"
      }`}
    >
      <div
        className={`mx-auto max-w-7xl px-4 sm:px-6 flex items-center justify-between rounded-2xl transition-all duration-500 ${
          scrolled ? "glass py-3 px-4 sm:px-6" : ""
        }`}
      >
        <a href="#home" className="flex items-center gap-2 group">
          <span className="text-2xl flicker">✦</span>
          <span className="flex flex-col leading-none">
            <span className="text-lg sm:text-xl font-extrabold tracking-tight neon-text">
              Владислав
            </span>
            <span className="text-[10px] sm:text-xs text-[var(--muted)] tracking-wide">
              Мастер световых вывесок и неона
            </span>
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm text-[var(--muted)] hover:text-white transition-colors relative after:absolute after:-bottom-1 after:left-0 after:h-px after:w-0 after:bg-[var(--neon)] hover:after:w-full after:transition-all after:duration-300"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          <a
            href={CONTACTS.phoneHref}
            className="btn-neon rounded-full px-5 py-2.5 text-sm"
          >
            Позвонить
          </a>
        </div>

        <button
          aria-label="Меню"
          onClick={() => setOpen((v) => !v)}
          className="md:hidden flex flex-col gap-1.5 p-2"
        >
          <span
            className={`h-0.5 w-6 bg-white transition-all ${open ? "translate-y-2 rotate-45" : ""}`}
          />
          <span className={`h-0.5 w-6 bg-white transition-all ${open ? "opacity-0" : ""}`} />
          <span
            className={`h-0.5 w-6 bg-white transition-all ${open ? "-translate-y-2 -rotate-45" : ""}`}
          />
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden mx-4 mt-2 overflow-hidden rounded-2xl glass transition-all duration-500 ${
          open ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <nav className="flex flex-col p-4 gap-1">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="px-3 py-3 rounded-lg text-[var(--muted)] hover:text-white hover:bg-white/5 transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href={CONTACTS.phoneHref}
            className="btn-neon rounded-full px-5 py-3 text-center mt-2"
          >
            Позвонить
          </a>
        </nav>
      </div>
    </header>
  );
}
