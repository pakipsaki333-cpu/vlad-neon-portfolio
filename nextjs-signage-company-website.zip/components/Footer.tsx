import { CONTACTS } from "./data";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <a href="#home" className="flex items-center gap-2">
            <span className="text-2xl flicker">✦</span>
            <span className="text-lg font-extrabold neon-text">Владислав</span>
          </a>

          <p className="text-sm text-[var(--muted)] text-center">
            Мастер световых вывесок и неона · изготовление, ремонт,
            восстановление
          </p>

          <div className="flex items-center gap-4">
            <a
              href={CONTACTS.phoneHref}
              className="text-sm text-[var(--muted)] hover:text-[var(--neon)] transition-colors"
            >
              {CONTACTS.phone}
            </a>
            <a
              href={CONTACTS.telegram}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-[var(--muted)] hover:text-[var(--neon)] transition-colors"
            >
              Telegram
            </a>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-white/5 text-center text-xs text-[var(--muted)]">
          © {new Date().getFullYear()} Владислав — мастер световых вывесок и
          неона. Все права защищены.
        </div>
      </div>
    </footer>
  );
}
