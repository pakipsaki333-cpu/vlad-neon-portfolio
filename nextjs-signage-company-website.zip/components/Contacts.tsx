import Reveal from "./Reveal";
import { CONTACTS } from "./data";

export default function Contacts() {
  return (
    <section id="contacts" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-4xl px-4 sm:px-6">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.5rem] glass p-8 sm:p-16 text-center">
            <div className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 h-72 w-72 rounded-full bg-[var(--neon)]/20 blur-[110px]" />
            <div className="pointer-events-none absolute inset-0 grid-bg opacity-30" />

            <div className="relative">
              <span className="text-sm uppercase tracking-[0.3em] text-[var(--neon-soft)]">
                Контакты
              </span>
              <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold tracking-tight neon-text">
                {CONTACTS.name}
              </h2>
              <p className="mt-3 text-[var(--muted)]">{CONTACTS.role}</p>

              <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href={CONTACTS.phoneHref}
                  className="btn-neon rounded-full px-8 py-4 text-base inline-flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  📞 {CONTACTS.phonePretty}
                </a>
                <a
                  href={CONTACTS.telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost rounded-full px-8 py-4 text-base inline-flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  ✈️ Telegram {CONTACTS.telegramHandle}
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
