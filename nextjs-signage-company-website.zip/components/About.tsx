import Image from "next/image";
import Reveal from "./Reveal";
import { aboutText, CONTACTS } from "./data";

export default function About() {
  return (
    <section id="about" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image side */}
          <Reveal>
            <div className="relative">
              <div className="absolute -inset-4 rounded-[2rem] bg-[var(--neon)]/15 blur-3xl" />
              <div className="relative overflow-hidden rounded-[2rem] glass p-2">
                <Image
                  src="/images/sign_20.jpg"
                  alt="Работа мастера над световой вывеской"
                  width={800}
                  height={1000}
                  className="rounded-[1.6rem] object-cover w-full h-[420px] sm:h-[520px]"
                />
              </div>
              <div className="absolute -bottom-6 -right-4 sm:right-6 glass rounded-2xl px-6 py-4 text-center">
                <div className="text-3xl font-extrabold neon-text">10+</div>
                <div className="text-xs text-[var(--muted)]">лет опыта</div>
              </div>
            </div>
          </Reveal>

          {/* Text side */}
          <div>
            <Reveal>
              <span className="text-sm uppercase tracking-[0.3em] text-[var(--neon-soft)]">
                О мастере
              </span>
              <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold tracking-tight">
                {CONTACTS.name} —{" "}
                <span className="neon-text">мастер световых вывесок</span>
              </h2>
            </Reveal>

            <div className="mt-8 space-y-4">
              {aboutText.map((p, i) => (
                <Reveal key={i} delay={i * 80}>
                  <p className="text-base sm:text-lg leading-relaxed text-[var(--muted)]">
                    {p}
                  </p>
                </Reveal>
              ))}
            </div>

            <Reveal delay={aboutText.length * 80}>
              <div className="mt-10 flex flex-wrap gap-3">
                {["Изготовление с нуля", "Ремонт", "Восстановление"].map(
                  (tag) => (
                    <span
                      key={tag}
                      className="glass rounded-full px-4 py-2 text-sm text-[var(--neon-soft)]"
                    >
                      {tag}
                    </span>
                  ),
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
