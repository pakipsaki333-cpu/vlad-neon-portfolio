import Reveal from "./Reveal";
import { reviews } from "./data";

export default function Reviews() {
  return (
    <section id="reviews" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute top-1/3 left-1/2 -translate-x-1/2 h-72 w-72 rounded-full bg-[var(--neon)]/10 blur-[130px]" />
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal>
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-sm uppercase tracking-[0.3em] text-[var(--neon-soft)]">
              Отзывы
            </span>
            <h2 className="mt-4 text-3xl sm:text-5xl font-extrabold tracking-tight">
              Мне <span className="neon-text">доверяют</span>
            </h2>
          </div>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {reviews.map((r, i) => (
            <Reveal key={r.name} delay={i * 80}>
              <figure className="glass glass-hover rounded-3xl p-7 h-full flex flex-col">
                <span className="text-4xl leading-none text-[var(--neon)]/40">
                  “
                </span>
                <blockquote className="mt-2 text-[15px] leading-relaxed text-[var(--text)]/90 flex-1">
                  {r.text}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--neon)]/15 text-[var(--neon)] font-bold ring-1 ring-[var(--neon)]/25">
                    {r.name.charAt(0)}
                  </div>
                  <div className="font-semibold">{r.name}</div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
